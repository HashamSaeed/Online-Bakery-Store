<?php

namespace App\Http\Controllers;
use App\Models\Product;
use DB;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('product.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('product.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'Product_Name' => 'required',
            'Number' => 'required',
            'Address' => 'required',
        ]);
  
        Product::create($request->all());
   
        return response()->json('product.index')->with('success','Request successful.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Product $product)
    {
        return view('product.show',compact('product'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Product $product)
    {
        return view('customer.edit',compact('customer'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Product $product)
    {
        $request->validate([
            'Product_Name' => 'required',
            'Number' => 'required',
            'Address' => 'required',
        ]);
  
        Product::update($request->all());
        return response()->json('product.index')->with('success','Request successful.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Product $product)
    {
        $product->delete();
    
        return response()->json('product.index')->with('success','Record deleted successfully');

    }
}
