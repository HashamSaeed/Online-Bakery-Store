<?php

namespace App\Http\Controllers;
use App\Models\Payment;
use DB;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('payment.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('payment.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'Order_ID' => 'required',
            'Payment_Method'=> 'required',
            'Total_Amount'=> 'required',
        ]);
  
        Payment::create($request->all());
   
        return response()->json('payment.index')->with('success','Request successful.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Payment $payment)
    {
        return view('payment.show',compact('payment'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Payment $payment)
    {
        return view('payment.edit',compact('payment'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Payment $payment)
    {
        $request->validate([
            'Order_ID' => 'required',
            'Payment_Method'=> 'required',
            'Total_Amount'=> 'required',
        ]);
  
        Payment::update($request->all());
   
        return response()->json('payment.index')->with('success','Request successful.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Payment $payment)
    {
        $payment->delete();

        return response()->json('payment.index')->with('success','Record deleted successfully.');
    }
}
