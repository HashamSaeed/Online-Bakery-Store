<?php

namespace App\Http\Controllers;
use App\Models\ContactUS;
use DB;
use Illuminate\Http\Request;

class ContactUsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('contact_us.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('contact_us.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required',
            'address' => 'required',
            'comments' => 'required'
        ]);
  
        ContactUS::create($request->all());
   
        return response()->json('contact_us.index')->with('success','Feedback created successfully.');

    }

    /**
     * Display the specified resource.
     */
    public function show(ContactUS $contact_us)
    {
        return view('contact_us.show',compact('contact_us'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ContactUS $contact_us)
    {
        return view('contact_us.edit',compact('contact_us'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, ContactUS $contact_us)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ContactUS $contact_us)
    {
        $contact_us->delete();
    
        return response()->json('contact_us.index')->with('success','Record deleted successfully');
    }
}
