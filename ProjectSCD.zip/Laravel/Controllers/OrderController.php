<?php

namespace App\Http\Controllers;
use App\Models\Order;
use DB;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('order.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('order.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'Customer_ID' => 'required',
            'User_ID' => 'required',
        ]);
  
        Order::create($request->all());
   
        return response()->json('order.index')->with('success','Request successful.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Order $order)
    {
        return view('order.show',compact('order'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Order $order)
    {
        return view('order.edit',compact('order'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Order $order)
    {
        $request->validate([
            'Customer_ID' => 'required',
            'User_ID' => 'required',
        ]);
  
        Order::update($request->all());
   
        return response()->json('order.index')->with('success','Request successful.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Order $order)
    {
        $order->delete();
    
        return response()->json('order.index')->with('success','Record deleted successfully');
    }
}
