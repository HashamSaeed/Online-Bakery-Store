<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\VideoUploaderController;
use App\Http\Controllers\PracticeController;
use App\Http\Controllers\MidController ;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('/practiceform',function(){
    return view('mids.practiceform');

});


Route::post('/practiceform',[MidController::class, 'store']);
Route::get('destroy',[MidController::class, 'destroy']);





Route::get('/practice/create', [PracticeController::class, 'create']);
Route::post('/practice/store', [PracticeController::class, 'store']);
Route::get('/practice', [PracticeController::class, 'index']);



Route::get('/dataview',function(){
    return view('dataview');
});

Route::get('/uploader',function(){
    return view('videouploader');
});
Route::get('/videoview', function () {
    return view('videoview');
});

Route::post('/uploader', [VideoUploadController::class, 'create']);

Route::post('/uploader', [VideoUploaderController::class, 'store'])->name('store');

Route::get('/videoview', [App\Http\Controllers\VideoUploaderController::class, 'index'])->name('videoview');

Route::get('/dataview', [App\Http\Controllers\VideoUploaderController::class, 'viewData'])->name('dataview');

Route::get('destroy-videos/{videos}', [App\Http\Controllers\VideoUploaderController::class, 'destroy']);

Route::get('edit/{videos}', [App\Http\Controllers\VideoUploaderController::class, 'edit']);

Route::get('update-videos/{videos}', [App\Http\Controllers\VideoUploaderController::class, 'update']);

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
