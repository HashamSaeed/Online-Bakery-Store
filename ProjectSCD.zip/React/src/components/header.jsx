import React from 'react';
import './header.css';
import { NavLink } from 'react-router-dom';
import { FaShoppingCart } from 'react-icons/fa';

function Header() {
  return (
    <div className="header">
      <div className="CompanyName">Bake Your Cake</div>

      <nav className="navbar">
        <ul className="nav-list">

        <li className="nav-item cart">
          <NavLink to={"/Cart"} className="cart-button"><FaShoppingCart /></NavLink>
          </li>

          <li className="nav-item">
            <NavLink to={"/"}>Home</NavLink>
          </li>

          <li className="nav-item dropdown">
            <span>Menu</span>
            <ul className="dropdown-list">
              <li>
                <NavLink to={"/Cake"}>Cakes</NavLink>
              </li>
              <li>
                <NavLink to={"/Brownie"}>Brownies</NavLink>
              </li>
            </ul>
          </li>

          <li className="nav-item">
            <NavLink to={"/Contact"}>Contact Us</NavLink>
          </li>

          <li className="nav-item">
            <NavLink to={"/WhatWeDo"}>About Us</NavLink>
          </li>

          
        </ul>

        <NavLink to={"/Login"} className="admin-button">Admin Panel</NavLink>
      </nav>

      
    </div>
  );
}

export default Header;
