import React from 'react';
import { NavLink } from 'react-router-dom';
import BrownieImages from './BrownieImg';


const Brownie = () => {
  return (
    <div className="cake-container">
      <div className="upper-row">

        <div className="image-container">
          <NavLink to={`/brownie/${BrownieImages[0].id}`}>
            <img src={BrownieImages[0].image} alt={BrownieImages[0].name} />
          </NavLink>
          
          <div className="image-text">
            <h4>{BrownieImages[0].name}</h4>
            <p>{BrownieImages[0].price}</p>
          </div>
        </div>


        <div className="image-container">
          <NavLink to={`/brownie/${BrownieImages[1].id}`}>
            <img src={BrownieImages[1].image} alt={BrownieImages[1].name} />
          </NavLink>
          <div className="image-text">
            <h4>{BrownieImages[1].name}</h4>
            <p>{BrownieImages[1].price}</p>
          </div>
        </div>
      </div>
      <div className="lower-row">
        <div className="image-container">
          <NavLink to={`/brownie/${BrownieImages[2].id}`}>
            <img src={BrownieImages[2].image} alt={BrownieImages[2].name} />
          </NavLink>
          <div className="image-text">
            <h4>{BrownieImages[2].name}</h4>
            <p>{BrownieImages[2].price}</p>
          </div>
        </div>
        <div className="image-container">
          <NavLink to={`/brownie/${BrownieImages[3].id}`}>
            <img src={BrownieImages[3].image} alt={BrownieImages[3].name} />
          </NavLink>
          <div className="image-text">
            <h4>{BrownieImages[3].name}</h4>
            <p>{BrownieImages[3].price}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Brownie;