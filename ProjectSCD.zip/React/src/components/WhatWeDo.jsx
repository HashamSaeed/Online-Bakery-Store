import React from 'react';
import './WhatWeDo.css';

function AboutUs() {
  return (
    <div className="about-us">
      <div className="background-image"></div>
      <div className="content">
        <h1>Mission</h1>
        <p>The love for Layers has only blossomed with time. We now have 8 stores in 
          different locations including Lahore and Islamabad- and this is just the beginning.
          Our dream to bake the best desserts in town continues to flourish, and we are over 
          the moon to have created a sweet utopia for dessert lovers to make their sweet 
          escape from reality to fantasy!</p>

        <h1>Vision</h1>
        <p>"Our vision is to create a delightful experience for our customers through our 
          passion for baking and commitment to quality. We strive to be the preferred destination
           for fresh and delicious baked goods, where every bite brings joy and satisfaction.
            We envision a bakery that captures the essence of warmth, comfort, and indulgence, 
            where our artisanal creations become a centerpiece of celebrations and everyday moments. By continuously innovating and staying true to our craftsmanship, we aim to inspire a love for baking and leave a lasting impression on taste buds and hearts alike. Our vision is to become a
           beloved bakery that adds sweetness to people's lives and creates lasting memories."</p>
      </div>
    </div>
  );
}

export default AboutUs;
