import './footer.css';

function footer() {
  return (
    <div className="footer">

        <div className='List1'>
            <ul>

                <h3>Customer Service</h3>
                <li>
                    Help & Contact Us
                </li>

                <li>
                    Returns & Refunds
                </li>

                <li>
                   Online Stores
                </li>

                <li>
                    Terms & conditions
                </li>
            </ul>

        </div>

        <div className='List2'>
            <ul>

                <h3>Company</h3>
                <li>
                    What We Do
                </li>

                <li>
                    Available Services
                </li>

                <li>
                   Latest Posts
                </li>

                <li>
                    FAQs
                </li>
            </ul>

        </div>

        <div className='List3'>
            <ul>

                <h3>Social Media</h3>
                <li>
                    Twitter
                </li>

                <li>
                    Instagram
                </li>

                <li>
                   Tumblr
                </li>

                <li>
                    Pinterest
                </li>
            </ul>

        </div>


        <div className='List4'>
            <ul>

                <h3>Profile</h3>
                <li>
                    My Account
                </li>

                <li>
                    Checkout
                </li>

                <li>
                   Order Tracking
                </li>

                <li>
                    Help & Support
                </li>
            </ul>

        </div>

       

      

    </div>
  );
}

export default footer;

