import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import cakeData from './CakeImg';

const CakeDetails = () => {
  const [cartItems, setCartItems] = useState([]);

  const addToCart = (cake) => {
    setCartItems([...cartItems, cake]);
  };

  const { id } = useParams();
  const cake = cakeData.find((item) => item.id === parseInt(id));

  if (!cake) {
    return <div>Item not found</div>;
  }

  const containerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    textAlign: 'center',
    padding: '20px',
  };

  const imageStyle = {
    maxWidth: '300px',
    height: 'auto',
    marginBottom: '10px',
  };

  const titleStyle = {
    fontSize: '24px',
    marginBottom: '5px',
  };

  const priceStyle = {
    fontSize: '16px',
    marginBottom: '10px',
  };

  const buttonStyle = {
    padding: '10px 20px',
    backgroundColor: '#f05d5e',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '16px',
  };

  const buttonHoverStyle = {
    backgroundColor: '#ff7f7f',
  };

  return (
    <div style={containerStyle}>
      <h2 style={titleStyle}>{cake.name}</h2>
      <img src={cake.image} alt={cake.name} style={imageStyle} />
      <p style={priceStyle}>Price: {cake.price}</p>
      <button
        style={buttonStyle}
        onClick={() => {
          addToCart(cake);
          alert('Added to Cart!');
        }}
      >
        Add to Cart
      </button>
    </div>
  );
};

export default CakeDetails;
