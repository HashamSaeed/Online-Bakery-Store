import React from 'react';
import { NavLink } from 'react-router-dom';

function LoginForm() {
  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
      <form style={{ border: '1px solid #ccc', padding: '20px', borderRadius: '5px' }}>
        <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Login</h2>
        <div style={{ marginBottom: '10px' }}>
          <label style={{ display: 'block', fontWeight: 'bold' }}>Username:</label>
          <input type="text" style={{ width: '89%', padding: '10px', borderRadius: '5px' }} />
        </div>
        <div style={{ marginBottom: '10px' }}>
          <label style={{ display: 'block', fontWeight: 'bold' }}>Password:</label>
          <input type="password" style={{ width: '89%', padding: '10px', borderRadius: '5px' }} />
        </div>
        <NavLink to="/Form">
          <button type="submit" style={{ width: '100%', padding: '10px', backgroundColor: '#007bff', color: '#fff', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>Log in</button>
        </NavLink>
      </form>
    </div>
  );
}

export default LoginForm;

