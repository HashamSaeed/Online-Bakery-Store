import React, { useState } from 'react';

const FoodForm = () => {
  const [formData, setFormData] = useState({
    image: null,
    title: '',
    price: '',
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleImageChange = (event) => {
    const imageFile = event.target.files[0];
    setFormData({
      ...formData,
      image: imageFile,
    });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    
    console.log(formData);
    setFormData({
      image: null,
      title: '',
      price: '',
    });
  };

  const formStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '20px',
  };

  const inputStyle = {
    marginBottom: '10px',
    padding: '8px',
    borderRadius: '5px',
    border: '1px solid #ccc',
    width: '300px',
  };

  const submitButtonStyle = {
    padding: '10px 20px',
    backgroundColor: '#f05d5e',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '16px',
  };

  return (
    <form style={formStyle} onSubmit={handleSubmit}>
      <h2>Add Bakery Item</h2>
      <input
        type="file"
        name="image"
        style={inputStyle}
        accept="image/*"
        onChange={handleImageChange}
      />
      <input
        type="text"
        name="title"
        placeholder="Title"
        style={inputStyle}
        value={formData.title}
        onChange={handleInputChange}
      />
      <input
        type="text"
        name="price"
        placeholder="Price"
        style={inputStyle}
        value={formData.price}
        onChange={handleInputChange}
      />
      <button type="submit" style={submitButtonStyle}>
        Add Bakery Item
      </button>
    </form>
  );
};

export default FoodForm;
