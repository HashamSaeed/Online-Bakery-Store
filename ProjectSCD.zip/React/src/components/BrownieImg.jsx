const BrownieImages = [
    {
      id: 1,
      image: "/images/p1.jpg",
      name: "Chocolate Cupcake",
      price: "1500 PKR"
    },
    {
      id: 2,
      image: "/images/p2.jpg",
      name: "Red Velvet Cupcake",
      price: "1200 PKR"
    },
    {
      id: 3,
      image: "/images/p3.jpg",
      name: "Penaut Butter Brownie",
      price: "1300 PKR"
    },
    {
      id: 4,
      image: "/images/p4.jpg",
      name: "Cadbury Brownie",
      price: "1400 PKR"
    }
  ];
  
  export default BrownieImages;