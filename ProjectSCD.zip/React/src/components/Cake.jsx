import React from 'react';
import { NavLink } from 'react-router-dom';
import cakeData from './CakeImg'; 
import './cake.css';

const Cake = () => {
  const containerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    textAlign: 'center',
    margin: '10px',
  };

  const imageStyle = {
    maxWidth: '200px',
    height: 'auto',
    marginBottom: '10px',
  };

  const nameStyle = {
    fontSize: '18px',
    fontWeight: 'bold',
  };

  const priceStyle = {
    fontSize: '16px',
  };

  return (
    <div className="cake-container">
      <div className="upper-row">
        {cakeData.slice(0, 2).map((cake) => (
          <div className="image-container" key={cake.id} style={containerStyle}>
            <NavLink to={`/cake/${cake.id}`}>
              <img src={cake.image} alt={cake.name} style={imageStyle} />
            </NavLink>
            <div className="image-text">
              <h4 style={nameStyle}>{cake.name}</h4>
              <p style={priceStyle}>{cake.price}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="lower-row">
        {cakeData.slice(2, 4).map((cake) => (
          <div className="image-container" key={cake.id} style={containerStyle}>
            <NavLink to={`/cake/${cake.id}`}>
              <img src={cake.image} alt={cake.name} style={imageStyle} />
            </NavLink>
            <div className="image-text">
              <h4 style={nameStyle}>{cake.name}</h4>
              <p style={priceStyle}>{cake.price}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Cake;




