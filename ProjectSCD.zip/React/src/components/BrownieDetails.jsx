import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import BrownieImages from './BrownieImg';

const BrownieDetails = () => {
  const [cartItems, setCartItems] = useState([]);

  const addToCart = () => {
    setCartItems([...cartItems, brownie]);
  };
  
  const { id } = useParams();
  const brownie = BrownieImages.find((item) => item.id === parseInt(id));

  if (!brownie) {
    return <div>Item not found</div>;
  }

  const containerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    textAlign: 'center',
    padding: '20px',
  };

  const imageStyle = {
    maxWidth: '300px',
    height: 'auto',
    marginBottom: '10px',
  };

  const titleStyle = {
    fontSize: '24px',
    marginBottom: '5px',
  };

  const priceStyle = {
    fontSize: '16px',
    marginBottom: '10px',
  };

  const buttonStyle = {
    padding: '10px 20px',
    backgroundColor: '#f05d5e',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '16px',
  };

  const buttonHoverStyle = {
    backgroundColor: '#ff7f7f',
  };

  return (
    <div style={containerStyle}>
      <h2 style={titleStyle}>{brownie.name}</h2>
      <img src={brownie.image} alt={brownie.name} style={imageStyle} />
      <p style={priceStyle}>Price: {brownie.price}</p>
      <button style={buttonStyle} onClick={addToCart}>
        Add to Cart
      </button>
    </div>
  );
};

export default BrownieDetails;
