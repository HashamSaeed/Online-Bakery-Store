
  
    const cakeData = [
      {
        id: 1,
        image: "/images/3milkCake.jpg",
        name: "3 Milk Cake",
        price: "1500 PKR"
      },
      {
        id: 2,
        image: "/images/german.jpg",
        name: "German Fudge Cake",
        price: "1200 PKR"
      },
      {
        id: 3,
        image: "/images/kitkat.jpg",
        name: "Kit Kat Cake",
        price: "1300 PKR"
      },
      {
        id: 4,
        image: "/images/rafaelo.jpg",
        name: "Rafaelo Cake",
        price: "1400 PKR"
      }
    ];
  
  
  export default cakeData;