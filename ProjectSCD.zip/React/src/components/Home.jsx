/*import React from 'react';
import tableImage from '../Images/table1.jpg';
import ballImg from '../Images/Ball2.jpg';
import holderImg from '../Images/BulbHolderSmall.jpg';
import VaseImg from '../Images/Vase.jpg';
import StorageImg from '../Images/Storage.jpg';
import FlowerImg from '../Images/flower.jpg';
import brand1Img from '../Images/brand1.png';
import brand2Img from '../Images/brand2.png';
import brand3Img from '../Images/brand3.png';
import brand4Img from '../Images/brand4.png';
import brand5Img from '../Images/brand5.png';
import './Home.css';

function Home() {
  return (
    
    <div className='home'>
      <div className='Upper'>
        <div className='RightImage'>
          <img src={tableImage} alt='Table' />
          <div class="top-left">DECORATIVE BASKETS</div>
          <div class="top-left2">FROM $40</div>
        </div>
        <div className='LeftImages'>
          <div className='Left1'>
          <img src={ballImg} alt='Ball' />
          <div class="top-left">ANTIQUE VASES</div>
          <div class="top-left2">HOME DECOR</div>
          </div>
          <div className='Left2'>
          <img src={holderImg} alt='Bulb Holder' />
          <div class="top-left">FIGURINES</div>
          <div class="top-left2">NEW!</div>
          </div>
        </div>
      </div>

      <div className='MidText'>
        <h6>W E L C O M E</h6>
        <p>
        Marketing is not Selling. Marketing is building a brand <br/>in the mind of the prospect.</p>
      </div>
    

    <div className='featured'>

      <pre> F E A T U R E D - I T E M S</pre>

      <div className='featuredImg'>
       <div className='ImgItem'>
       <img src={VaseImg} alt='Pottery Vase' />
       <p> POTTERY VASE</p>
       <p className='price1'>60$</p>
       </div>

       <div className='ImgItem'>
       <img src={StorageImg} alt='Newspaper Storage' />
       <p> NEWSPAPER STORAGE</p>
       <p className='price2'>90$</p>
       </div>

       <div className='ImgItem'>
       <img src={FlowerImg} alt='FLOWER VASE' />
       <p> FLOWER VASE</p>
       <p className='price3'>170$</p>
       </div>

      </div>

    </div>

    <div className='brandNames'>
          <img src={brand1Img} alt='' />
          <img src={brand2Img} alt='' />
          <img src={brand3Img} alt='' />
          <img src={brand4Img} alt='' />
          <img src={brand5Img} alt='' />
    </div>

    </div>
  );
}

export default Home;*/

import { NavLink } from 'react-router-dom';
import './Home.css';

import blue from '../Images/Blueberry.png'
import F1 from '../Images/p1.jpg'
import F2 from '../Images/p2.jpg'
import F3 from '../Images/p3.jpg'
import backgroundImage from '../Images/homebackground.png'
import milkCake from'../Images/3milkCake.jpg'
import Fcake from '../Images/FCake.jpg'

function Home() {
  const featuredItems = [
    { image: F1, name: 'CHOCOLATE MOUSSE', price: '200 PKR', id: 1 },
    { image: F3, name: 'PEANUT BUTTER', price: '300 PKR', id: 2 },
    { image: F2, name: 'RED VELVET', price: '200 PKR', id: 3 },
  ];

  const handleButtonClick = () => {
    // Logic for handling button click
    console.log('Button clicked! Navigating to next page...');
    // You can add your navigation logic here using React Router's history or NavLink
  };

  return (
   
    <div className='home'>
       <h1 className='heading'>Get Your Cake Baked!</h1>
      
      <div className='Top-Image' style={{ backgroundImage: `url(${backgroundImage})` }}>
      
        <div className='blur-overlay'></div>
        
      </div>
      <NavLink to={"/Cake"} className='button' onClick={handleButtonClick}>
        Shop Here
      </NavLink>

      <div className='Upper'>
        <div className='RightImage'>
          <NavLink className="myNavLink">
          <img src={blue} alt='cake' />
          <div className='top-left'>BLUEBERRY WHITE CHOCOLATE</div>
          <div className='top-left2'>2500 PKR</div>
          </NavLink>
        </div>
        <div className='LeftImages'>
          <div className='Left1'>
            <NavLink className="myNavLink">
            <img src={milkCake} alt='cake' />
            <div className='top-left'>3 MILK CAKE</div>
            <div className='top-left2'>1500 PKR</div>
            </NavLink>
          </div>
          <div className='Left2'>
          <NavLink className="myNavLink">
            <img src={Fcake} alt='cake' />
            <div className='top-left'>FERRERO ROCHER</div>
            <div className='top-left2'>2000 PKR</div>
            </NavLink>
          </div>
        </div>
      </div>

      <div className='MidText'>
        <h6>W E L C O M E</h6>
        <p>"Indulge in the sweetest creations at our cake bakery shop."</p>
      </div>

      <div className='featured'>
        <div className='featuredHeader'>
          <pre> F E A T U R E D - I T E M S</pre>
        </div>
        
          <div className='featuredImgContainer'>
            <div className='featuredImg'>
              {featuredItems.map((item, index) => (
                <NavLink to={`/Home/${item.id}`} key={index} className="myNavLink">
                  <div className='ImgItem'>
                    <img src={item.image} alt={item.name} />
                    <p>{item.name}</p>
                    <p className={`price${index + 1}`}>{item.price}</p>
                  </div>
                </NavLink>
              ))}
            </div>
          </div>
        
      </div>
    </div>
  );
}

export default Home;


