import './WhatWeDo.css';
import React, { useState } from 'react';
import axios from 'axios';
import { FaFacebook, FaInstagram, FaTwitter } from 'react-icons/fa';

function ContactUs() {

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [comments, setComments] = useState('');


  const data = {name, email, address, comments};
console.log(data);

const handleSubmit = async (e) => {
e.preventDefault();
await axios.post('http://127.0.0.1:8000/api/store',
data,
{
headers:{
'content-type': 'multipart/form-data',
}
}).then( (e)=> {
console.log(e.data);
}).catch((error) => {console.error(error)})
}
  
  return (
    <div className="contact-us">
      <div className="background-image1"></div>
      <div className="content1">
        <h1>Contact Us</h1>
        <div className="contact-form">
        <h2>Feedback and Suggestions</h2>
          <form onSubmit={handleSubmit}>
             <label htmlFor="name">Name</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />

              <label htmlFor="email">Email</label>
                <input
                  type="email"
                  id="email"
                   name="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                />

      <label htmlFor="address">Address</label>
      <input
        type="text"
        id="address"
        name="address"
        value={address}
        onChange={(e) => setAddress(e.target.value)}
      />

      <label htmlFor="comments">Comments</label>
      <textarea
        id="comments"
        name="comments"
        rows="4"
        value={comments}
        onChange={(e) => setComments(e.target.value)}
      />

      <button type="submit">Submit</button>
    </form>
          
        </div>

        <hr></hr>

        <div className="social-media">
          <h2>Social Media</h2>
          <div className="social-icons">
            <a href="#" className="social-icon1">
              <FaFacebook size={50} />
              <span>bakemycake/facebook</span>
            </a>
            <a href="#" className="social-icon2">
              <FaInstagram size={50} />
              <span>bakemycake/Instagram</span>
            </a>
            <a href="#" className="social-icon3">
              <FaTwitter size={50} />
              <span>bakemycake/Twitter</span>
            </a>
          </div>
          <p>Connect with us on social media to stay updated with our latest news and promotions.</p>
        </div>
      </div>
    </div>
  );
}

export default ContactUs;
