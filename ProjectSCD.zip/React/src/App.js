import logo from './logo.svg';
import './App.css';
import { BrowserRouter } from 'react-router-dom';
import Pages from './pages/pages';
import Header from './components/header';
import Footer from './components/footer';

function App() {
  return (
    
    <BrowserRouter>
    <Header />
    <Pages />
    <Footer />
    </BrowserRouter>

    
  );
}

export default App;
