import React from 'react';
import Home  from '../components/Home'


function main() {
  return (
    <div className="container" >
        <Home/>
    </div>
  )
}

export default main;