import React from 'react';
import { Route, Routes } from 'react-router-dom';
import WhatWeDo from '../components/WhatWeDo';
import ContactUs from '../components/Contact';
import Cake from '../components/Cake';
import Brownie from '../components/Brownie';
import Home from './main';
import Login from '../components/Login';
import BrownieDetails from '../components/BrownieDetails';
import CakeDetails from '../components/CakeDetails';
import Form from '../components/Form';

const pages = () => {
  return (
    <Routes>
        <Route path='/' element={ <Home/>} />
        <Route path='/WhatWeDo' element={ <WhatWeDo/>} />
        <Route path='/Contact' element={ <ContactUs/>} />
        <Route path='/Cake' element={ <Cake/>} />
        <Route exact path="/brownie/:id" element={ <BrownieDetails/>} />
        <Route exact path="/cake/:id" element={ <CakeDetails/>} />
        <Route path='/Brownie' element={ <Brownie/>} />
        <Route path='/Login' element={ <Login/>} />
        <Route path='/Form' element={ <Form/>} />
    </Routes>
  )
}

export default pages;