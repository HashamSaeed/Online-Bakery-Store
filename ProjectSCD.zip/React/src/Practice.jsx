import {React, useState} from 'react';


/*const Practice=()=>{

    const [status,setStatus]=useState(true);
    
    return(

        <div>
            {


           status? <h1>True</h1> : null
}
            <button type='submit'onClick={()=>setStatus(true)}>Show</button>
            <button type='submit' onClick={()=>setStatus(false)}>Hide</button>

        </div>

    );
}


export default Practice;*/


const Practice=()=>{

    const [name,setName]=useState("");
    const [type,setType]=useState("");

    function getData(e)
    {
        e.preventDefault();
        console.log(name,type);
    }
    
    return(

        <div>
            <form onSubmit={getData}>
                <label for='name'>Name</label>
                <input type='text' onChange={(e)=>setName(e.target.value)}/>
                
                <select onChange={(e)=>setType(e.target.value)}>
                    <option>Marvel</option>
                    <option>DC</option>
                </select>

                <button type='submit' >Submit</button>

                
            </form>
        </div>
    );
}


export default Practice;